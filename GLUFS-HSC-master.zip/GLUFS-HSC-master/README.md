The MATLAB code of the paper 'A Global and Local Unified Feature Selection Algorithm Based on
Hierarchical Structure Constraints'

Run the file GLUFSHSC_main.m. 
