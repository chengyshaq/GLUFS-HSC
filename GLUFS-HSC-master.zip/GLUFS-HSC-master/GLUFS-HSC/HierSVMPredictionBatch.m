%% Date: 2018-2-8
% �޸�˵����
% 1. ����������ݼ�ֻѡ10%20%30%40%50%������
% 2. ��������SVM����c=1����
% 3. ͼ������ݼ�ѡ20%���������������ݼ�ѡ10%����
function [accuracyMean, accuracyStd, F_LCAMean, FHMean, TIEmean, TestTime] = HierSVMPredictionBatch(data_array, tree, feature)
[m, numFeature] = size(data_array);
numFeature = numFeature - 1; 
numFolds  = 10;
k = 1;
baseline = 0;
% Test all features (baseline)
% Test 50% 40%	30%	20%	10% features.
a=[1,10];
for j = 1:2
%     numSeleted = a(j);
    numSeleted = round(numFeature * a(j) * 0.1);
    accuracyMean(1, k) = numSeleted;
    accuracyStd(1, k) = numSeleted;
    F_LCAMean(1, k) = numSeleted;
    FHMean(1, k) = numSeleted;
    TIEmean(1, k) = numSeleted;
    TestTime(1, k) = numSeleted;
    rand('seed', 1);
    indices = crossvalind('Kfold', m, numFolds);
    tic;
    [accuracyMean(2, k), accuracyStd(2, k), F_LCAMean(2, k), FHMean(2, k), TIEmean(2, k)] = FS_Kflod_TopDownSVMClassifier(data_array, numFolds, tree, feature, numSeleted, indices);
    TestTime(2, k) = toc;
    k = k+1;
end
%  if (baseline == 1)
%     accuracyMean(1, k) = numFeature;
%     accuracyStd(1, k) = numFeature;
%     F_LCAMean(1, k) = numFeature;
%     FHMean(1, k) = numFeature;
%     TIEmean(1, k) = numFeature;
%     TestTime(1, k) = numFeature;
%     rand('seed', 1);
%     indices = crossvalind('Kfold', m, numFolds);
%     tic;
%     [accuracyMean(2, k), accuracyStd(2, k), F_LCAMean(2, k), FHMean(2, k), TIEmean(2, k)] = FS_Kflod_TopDownSVMClassifier(data_array, numFolds, tree, feature, numFeature, indices);
%     TestTime(2, k) = toc;
%  end
end
