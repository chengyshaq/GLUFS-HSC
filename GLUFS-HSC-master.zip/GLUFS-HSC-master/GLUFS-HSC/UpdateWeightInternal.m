%% 更新内部节点的权重矩阵 (包含双向父子节点依赖)
function W_node = UpdateWeightInternal(XX, XY, D, W, nodeIndex, tree, lambda, alpha, beta, a, b)
    % 获取父节点索引
    parentIndex = tree_Parent(tree, nodeIndex);

    % 计算兄弟节点相关矩阵
    siblingNodes = tree_Sibling(tree, nodeIndex);
    siblingNodes = setdiff(siblingNodes, tree_LeafNode(tree));  % 排除叶节点

    U1 = zeros(size(XX));
    U2 = zeros(size(XY));
    U = zeros(size(XX));

    for jj = 1:length(siblingNodes)
        siblingIndex = siblingNodes(jj);
        W_sibling = W{siblingIndex};
        U1 = U1 + W_sibling * W_sibling';
        U2 = U2 + W_sibling;
        U = U + W_sibling * W_sibling';
    end

    % 更新权重矩阵，融合所有约束项 (双向父子节点依赖)
    W_parent = W{parentIndex};
    % 父节点对当前节点的约束
    parentChildConsis = a * (W{nodeIndex} - W_parent);
    % 当前节点对父节点的反向约束
    childParentConsis = a * (W_parent - W{nodeIndex});
    
    W_node = (XX + lambda * D + beta * (ones(size(XX)) - eye(size(XX))) + a * eye(size(XX)) + alpha * U1 + b * U) \ (XY + parentChildConsis + childParentConsis + alpha * U2);
end