%% 计算目标函数值（可选）
function objValue = ComputeObjective(X, Y, W, D, tree, lambda, alpha, beta, a, b, noLeafNode)
    objValue = 0;
    for i = 1:length(noLeafNode)
        nodeIndex = noLeafNode(i);
        W_node = W{nodeIndex};
        X_node = X{nodeIndex};
        Y_node = Y{nodeIndex};
        D_node = D{nodeIndex};

        % 计算重构误差
        error = 0.5 * norm(X_node * W_node - Y_node, 'fro')^2;

        % 计算正则化项
        reg = lambda * sum(sqrt(sum(W_node .^ 2, 2)));

        % 计算类间距离项
        interClass = beta * trace((ones(size(W_node, 1)) - eye(size(W_node, 1))) * W_node * W_node');

        % 计算父子节点一致性约束 (双向约束)
        if nodeIndex ~= tree_Root(tree)
            parentIndex = tree_Parent(tree, nodeIndex);
            W_parent = W{parentIndex};
            parentChild = a * norm(W_node - W_parent, 'fro')^2 + a * norm(W_parent - W_node, 'fro')^2;
        else
            parentChild = 0;
        end

        % 计算兄弟节点相关性约束
        siblingNodes = tree_Sibling(tree, nodeIndex);
        
        siblingNodes = setdiff(siblingNodes, tree_LeafNode(tree));  % 排除叶节点
        siblingConsis = 0;
        for jj = 1:length(siblingNodes)
            siblingIndex = siblingNodes(jj);
            W_sibling = W{siblingIndex};
            siblingConsis = siblingConsis + alpha * norm(W_node' * W_sibling - eye(size(W_node, 2)), 'fro')^2 + b * HSIC(W_node, W_sibling);
        end

        % 累加到目标函数值
        objValue = objValue + error + reg + interClass + parentChild + siblingConsis;
    end
end