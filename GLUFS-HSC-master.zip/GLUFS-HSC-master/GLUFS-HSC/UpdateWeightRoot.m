%% 更新根节点的权重矩阵
function W_root = UpdateWeightRoot(XX, XY, D, W, indexRoot, lambda, beta, a)
    % 计算兄弟节点相关矩阵（根节点没有兄弟节点，忽略 alpha 和 b 项）
    % 考虑到父子节点关系，根节点的父节点为自身
    W_parent = W{indexRoot};
    W_root = (XX + lambda * D + beta * (ones(size(XX)) - eye(size(XX))) + a * eye(size(XX))) \ (XY + a * W_parent);
end