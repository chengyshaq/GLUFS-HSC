%% 特征选择算法主函数（每次运行一个数据集）

% 清空环境和变量
clc; clear;
%  str1={'Bridges02'};
%  load('Bridges02Train.mat', 'data_array');
%  load('Bridges02Train.mat', 'tree');
% 指定要处理的数据集名称
str1={'Bridges';'DD';'F194';'CLEF';'VOC';'Car196';'ILSVRC57';'SUN'};
i = 2;
    indx=[];
    datasetName = str1{i};
    % 根据数据集设置参数
if strcmp(datasetName, 'Bridges')
%        lambda = 10; alpha = 0.1; beta = 0.1; a = 0.1; b = 0.1;  % 生物数据集参数  
    lambda = 1; alpha = 100; beta = 100; a = 10; b = 0.01;
elseif strcmp(datasetName, 'DD') 
%         lambda = 10; alpha = 10; beta = 0.1; a = 0; b = 10;
        lambda = 10; alpha = 10; beta = 0.1; a = 1; b = 10;
elseif strcmp(datasetName, 'F194')
%      lambda = 10; alpha = 0.1; beta = 0.1; a = 0.1; b = 0.1;% 图像数据集参数
     lambda = 10; alpha = 1; beta = 0.01; a = 0.01; b = 1;
elseif  strcmp(datasetName, 'CLEF')
%       lambda = 100; alpha = 0.1; beta = 0.1; a = 0.1; b = 0.1; 
     lambda = 100; alpha = 0.1; beta = 100; a = 1; b = 1; 
%      lambda = 100; alpha = 10; beta = 100; a = 10; b = 100; 
elseif  strcmp(datasetName, 'VOC')   
%     lambda = 10; alpha = 1; beta = 1; a = 1; b = 1;
%      lambda = 1; alpha = 0.1; beta = 0.1; a = 1; b = 1;
     lambda = 1; alpha = 1; beta = 0.01; a = 1; b = 0.01;
elseif  strcmp(datasetName, 'Car196')   
%     lambda = 100; alpha = 1; beta = 1; a = 1; b = 1;
%     lambda = 100; alpha = 0.1; beta = 0.1; a = 0.1; b = 0.1; 
     lambda = 100; alpha = 10; beta = 100; a = 10; b = 1;
elseif  strcmp(datasetName, 'ILSVRC57')   
     lambda = 100; alpha = 0.01; beta = 1; a = 0.1; b = 0.01;
elseif  strcmp(datasetName, 'SUN')   
     lambda = 10; alpha = 0.01; beta = 0.01; a = 0.1; b = 10;
%     lambda = 14; alpha = 0.5; beta = 1.1; a = 0.4; b = 0.5;
end

% 设置迭代次数
if strcmp(datasetName, 'Bridges') || strcmp(datasetName, 'DD')|| strcmp(datasetName, 'VOC')||strcmp(datasetName, 'ILSVRC57')
    maxIte = 10;
elseif  strcmp(datasetName, 'CLEF')|| strcmp(datasetName, 'Car196')
%     maxIte = 15;
    maxIte = 10;
elseif strcmp(datasetName, 'F194')
    maxIte = 20;
elseif strcmp(datasetName, 'SUN')
%     maxIte = 25;
    maxIte = 30;
end

% 加载训练数据
trainFilename = [datasetName, 'Train.mat'];  % 训练数据文件名
if exist(trainFilename, 'file')
    load(trainFilename);  % 加载训练数据，变量名应包含 data_array 和 tree
else
    error(['训练数据文件 ', trainFilename, ' 不存在。请检查文件名和路径。']);
end

% 创建子表，提取特征和标签
[X, Y] = creatSubTablezh(data_array, tree);

% 特征选择
tic;  % 开始计时
flag = 1;  % 不绘制目标函数曲线
[feature] = GLUFSHSC_main_FS(X, Y, tree, lambda, alpha, beta, a, b, maxIte, flag);  % 调用特征选择函数
TrainTime = toc;  % 记录特征选择时间

% 加载测试数据
testFilename = [datasetName, 'Test.mat'];  % 测试数据文件名
if exist(testFilename, 'file')
    load(testFilename);  % 加载测试数据，变量名应包含 data_array 和 tree
else
    error(['测试数据文件 ', testFilename, ' 不存在。请检查文件名和路径。']);
end

% 进行分类预测
[accuracyMean, accuracyStd, F_LCAMean, FHMean, TIEmean, TestTime] = HierSVMPredictionBatch(data_array, tree, feature);

% 显示结果
fprintf('Dataset: %s\n', datasetName);
fprintf('Accuracy Mean: %.4f, Std: %.4f\n', accuracyMean, accuracyStd);
fprintf('Training Time: %.2f seconds\n', TrainTime);
fprintf('Testing Time: %.2f seconds\n\n', TestTime);

% 保存结果
resultFilename = ['UnifiedResult_', datasetName, '.mat'];  % 结果文件名
save(resultFilename, 'lambda', 'alpha', 'beta', 'a', 'b', 'accuracyMean', 'accuracyStd', 'F_LCAMean', 'FHMean', 'TIEmean', 'TrainTime', 'feature', 'TestTime');
