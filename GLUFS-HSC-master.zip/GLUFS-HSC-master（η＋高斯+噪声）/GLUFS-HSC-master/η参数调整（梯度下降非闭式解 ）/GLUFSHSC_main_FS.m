function [feature_slct] = GLUFSHSC_main_FS(X, Y, tree, lambda, alpha, beta, a, b, eta, maxIte, maxInnerIter, flag)
    % 提取非叶节点和根节点
    internalNodes = tree_InternalNodes(tree);  
    indexRoot = tree_Root(tree);               
    noLeafNode = [internalNodes; indexRoot];   
    numSelected = size(X{indexRoot},2);        

    % 获取每个节点的类别数
    for i = 1:length(noLeafNode)
        ClassLabel = unique(Y{noLeafNode(i)});
        m(noLeafNode(i)) = length(ClassLabel);
    end
    maxm = max(m);  

    % 初始化权重矩阵（小随机数）
    for j = 1:length(noLeafNode)
        [~, d] = size(X{noLeafNode(j)});  
        Y{noLeafNode(j)} = conversionY01_extend(Y{noLeafNode(j)}, maxm);  
        W{noLeafNode(j)} = 0.01 * randn(d, maxm);  % 减小初始化幅度
    end

    % 迭代优化
    obj = zeros(maxIte, 1);  % 存储目标函数值
    for iter = 1:maxIte
        % ===== 计算正则化矩阵（添加稳定性）=====
        for j = 1:length(noLeafNode)
            W_node = W{noLeafNode(j)};
            epsilon = 1e-8;
            row_norms = sqrt(sum(W_node.^2, 2)) + epsilon;  % 防止除以零
            D{noLeafNode(j)} = diag(0.5 ./ row_norms);
            XX{noLeafNode(j)} = X{noLeafNode(j)}' * X{noLeafNode(j)} + 1e-8 * eye(size(X{noLeafNode(j)},2));  % 添加正则化防止矩阵奇异
            XY{noLeafNode(j)} = X{noLeafNode(j)}' * Y{noLeafNode(j)};
        end

        % ===== 更新根节点权重 =====
        W{indexRoot} = UpdateWeightRoot(XX{indexRoot}, XY{indexRoot}, D{indexRoot}, W, indexRoot, lambda, beta, a, eta, maxInnerIter);

        % ===== 更新内部节点权重 =====
        for j = 1:length(internalNodes)
            nodeIndex = internalNodes(j);
            W{nodeIndex} = UpdateWeightInternal(XX{nodeIndex}, XY{nodeIndex}, D{nodeIndex}, W, nodeIndex, tree, lambda, alpha, beta, a, b, eta, maxInnerIter);
        end

        % ===== 计算目标函数值（含NaN检查）=====
        if flag == 1
            obj(iter) = ComputeObjective(X, Y, W, D, tree, lambda, alpha, beta, a, b, noLeafNode);
            if isnan(obj(iter))
                error('NaN detected in objective at iteration %d. Check gradients.', iter);
            end
            fprintf('Iter: %03d, Loss: %.4f, η: %.4f\n', iter, obj(iter), eta);
        end
    end

    % ===== 特征选择 =====
    for i = 1:length(noLeafNode)
        W1 = W{noLeafNode(i)};
        W{noLeafNode(i)} = W1(:, 1:m(noLeafNode(i)));  % 截断无效类别列
    end
    for j = 1:length(noLeafNode)
        tempVector = sum(W{noLeafNode(j)}.^2, 2);
        [~, idx] = sort(tempVector, 'descend');
        feature_slct{noLeafNode(j)} = idx(1:numSelected);
    end

if flag == 1
    figure('Color',[1 1 1], 'Position',[100 100 600 400]);
    plot(1:maxIte, obj, 'b-o', 'LineWidth',1.5);
    xlabel('Iteration');
    ylabel('Objective Value');
    
    % 动态选择显示格式
    if eta < 0.001
        title(sprintf('Convergence (η=%.1e)', eta));
    else
        title(sprintf('Convergence (η=%.3f)', eta));
    end
    
    grid on;
end
end