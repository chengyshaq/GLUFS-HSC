function W_root = UpdateWeightRoot(XX, XY, D, W, indexRoot, lambda, beta, a, eta, maxInnerIter)
    W_current = W{indexRoot};
    [d, m] = size(W_current);
    
    for innerIter = 1:maxInnerIter
        % 计算梯度
        grad_recon = XX * W_current - XY;
        grad_sparse = lambda * D * W_current;
        grad_interclass = beta * (ones(d) - eye(d)) * W_current;
        grad_parent = a * (W_current - W{indexRoot});  % 根节点自约束
        
        total_grad = grad_recon + grad_sparse + grad_interclass + grad_parent;
        
        % 梯度裁剪（防止爆炸）
        grad_norm = norm(total_grad, 'fro');
        max_grad_norm = 100;
        if grad_norm > max_grad_norm
            total_grad = total_grad * (max_grad_norm / grad_norm);
        end
        
        % 更新权重
        W_current = W_current - eta * total_grad;
        
        % 检查NaN
        if any(isnan(W_current(:)))
            error('NaN in root weights at inner iter %d', innerIter);
        end
    end
    W_root = W_current;
end