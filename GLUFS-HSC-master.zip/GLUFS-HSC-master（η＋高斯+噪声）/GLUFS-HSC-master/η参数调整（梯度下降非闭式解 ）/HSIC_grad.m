function grad = HSIC_grad(W1, W2)
    n = size(W1, 1);
    H = eye(n) - ones(n)/n;  % Centering matrix
    K1 = W1 * W1' + 1e-8 * eye(n);  % �������򻯷�ֹ����
    K2 = W2 * W2' + 1e-8 * eye(n);
    grad = 2 * H * K1 * H * W2 + 2 * H * K2 * H * W1;
end