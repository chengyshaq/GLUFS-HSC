function objValue = ComputeObjective(X, Y, W, D, tree, lambda, alpha, beta, a, b, noLeafNode)
    objValue = 0;
    for i = 1:length(noLeafNode)
        nodeIndex = noLeafNode(i);
        W_node = W{nodeIndex};
        X_node = X{nodeIndex};
        Y_node = Y{nodeIndex};
        
        % 重构误差
        error_term = 0.5 * norm(X_node * W_node - Y_node, 'fro')^2;
        
        % 稀疏正则化
        reg_sparse = lambda * sum(sqrt(sum(W_node.^2, 2)) + 1e-8);  % 添加极小值
        
        % 类间距离
        interclass_term = beta * trace((ones(size(W_node,1)) - eye(size(W_node,1))) * W_node * W_node');
        
        % 父子节点约束
        if nodeIndex ~= tree_Root(tree)
            parentIndex = tree_Parent(tree, nodeIndex);
            W_parent = W{parentIndex};
            parent_child_term = a * (norm(W_node - W_parent, 'fro')^2 + norm(W_parent - W_node, 'fro')^2);
        else
            parent_child_term = 0;
        end
        
        % 兄弟节点约束
        siblingNodes = setdiff(tree_Sibling(tree, nodeIndex), tree_LeafNode(tree));
        sibling_term = 0;
        for jj = 1:length(siblingNodes)
            W_sibling = W{siblingNodes(jj)};
            sibling_term = sibling_term + alpha * norm(W_node' * W_sibling - eye(size(W_node,2)), 'fro')^2 + b * HSIC(W_node, W_sibling);
        end
        
        % 累加目标函数
        objValue = objValue + error_term + reg_sparse + interclass_term + parent_child_term + sibling_term;
    end
end