function W_node = UpdateWeightInternal(XX, XY, D, W, nodeIndex, tree, lambda, alpha, beta, a, b, eta, maxInnerIter)
    parentIndex = tree_Parent(tree, nodeIndex);
    W_parent = W{parentIndex};
    W_current = W{nodeIndex};
    [d, m] = size(W_current);
    siblingNodes = setdiff(tree_Sibling(tree, nodeIndex), tree_LeafNode(tree));
    
    for innerIter = 1:maxInnerIter
        % ===== 计算梯度分量 =====
        grad_recon = XX * W_current - XY;
        grad_sparse = lambda * D * W_current;
        grad_interclass = beta * (ones(d) - eye(d)) * W_current;
        grad_parent = 4 * a * (W_current - W_parent);  % 双向约束
        
        % 兄弟节点正交约束
        grad_orth = zeros(d, m);
        for jj = 1:length(siblingNodes)
            W_sibling = W{siblingNodes(jj)};
            grad_orth = grad_orth + alpha * 2 * W_sibling * (W_current' * W_sibling - eye(m));
        end
        
        % HSIC约束
        grad_HSIC = zeros(d, m);
        for jj = 1:length(siblingNodes)
            W_sibling = W{siblingNodes(jj)};
            grad_HSIC = grad_HSIC + b * HSIC_grad(W_current, W_sibling);
        end
        
        total_grad = grad_recon + grad_sparse + grad_interclass + grad_parent + grad_orth + grad_HSIC;
        
        % ===== 梯度裁剪 =====
        grad_norm = norm(total_grad, 'fro');
        max_grad_norm = 100;
        if grad_norm > max_grad_norm
            total_grad = total_grad * (max_grad_norm / grad_norm);
        end
        
        % ===== 更新权重 =====
        W_current = W_current - eta * total_grad;
        
        % ===== 数值检查 =====
        if any(isnan(W_current(:)))
            error('NaN in node %d at inner iter %d', nodeIndex, innerIter);
        end
    end
    W_node = W_current;
end