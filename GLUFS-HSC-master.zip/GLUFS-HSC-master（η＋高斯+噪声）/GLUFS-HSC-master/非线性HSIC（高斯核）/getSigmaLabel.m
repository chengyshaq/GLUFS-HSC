function label = getSigmaLabel(sigma)
    if isempty(sigma)
        label = 'auto';
    elseif ischar(sigma)
        label = sigma;
    else
        label = num2str(sigma,'%.1f');
    end
end

