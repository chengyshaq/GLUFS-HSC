%% 修正后的ComputeObjective函数
function [objValue, avgHSIC, totalTime] = ComputeObjective(X, Y, W, D, tree, lambda, alpha, beta, a, b, noLeafNode, kernelType, sigma)
    objValue = 0;
    totalTime = 0;
    hsicVals = [];
    
    for i = 1:length(noLeafNode)
        nodeIndex = noLeafNode(i);
        W_node = W{nodeIndex};
        X_node = X{nodeIndex};
        Y_node = Y{nodeIndex};
        D_node = D{nodeIndex};

        % 计算重构误差
        error = 0.5 * norm(X_node * W_node - Y_node, 'fro')^2;

        % 正则化项
        reg = lambda * sum(sqrt(sum(W_node .^ 2, 2)));

        % 类间距离项
        interClass = beta * trace((ones(size(W_node, 1)) - eye(size(W_node, 1))) * W_node * W_node');

        % 父子节点约束
        if nodeIndex ~= tree_Root(tree)
            parentIndex = tree_Parent(tree, nodeIndex);
            W_parent = W{parentIndex};
            parentChild = a * norm(W_node - W_parent, 'fro')^2 + a * norm(W_parent - W_node, 'fro')^2;
        else
            parentChild = 0;
        end

        % 兄弟节点约束
        siblingNodes = setdiff(tree_Sibling(tree, nodeIndex), tree_LeafNode(tree));
        siblingConsis = 0;
        for jj = 1:length(siblingNodes)
            siblingIndex = siblingNodes(jj);
            W_sibling = W{siblingIndex};
            
            % 调用修正后的HSIC函数
            [hsicVal, ~, hsicTime] = HSIC(W_node, W_sibling, kernelType, sigma);
            hsicVals = [hsicVals; hsicVal];
            totalTime = totalTime + hsicTime;
            
            % 其他约束项
            siblingConsis = siblingConsis + alpha * norm(W_node' * W_sibling - eye(size(W_node, 2)), 'fro')^2;
        end

        objValue = objValue + error + reg + interClass + parentChild + siblingConsis + b*sum(hsicVals);
    end
    avgHSIC = mean(hsicVals);
end