%% 修正后的UpdateWeightInternal函数
function W_node = UpdateWeightInternal(XX, XY, D, W, nodeIndex, tree, lambda, alpha, beta, a, b, kernelType, sigma) 
% 获取父节点索引
    parentIndex = tree_Parent(tree, nodeIndex);
    
    % 获取当前节点权重
    W_current = W{nodeIndex};
    
    % 计算兄弟节点
    siblingNodes = setdiff(tree_Sibling(tree, nodeIndex), tree_LeafNode(tree));
    
    % 初始化约束项
    U1 = zeros(size(XX));
    U2 = zeros(size(XY));
    U_HSIC = zeros(size(XX));

    for jj = 1:length(siblingNodes)
        siblingIndex = siblingNodes(jj);
        W_sibling = W{siblingIndex};
        
        % 计算HSIC约束
        [hsic_val, ~, ~] = HSIC(W_current, W_sibling, kernelType, sigma);
        U_HSIC = U_HSIC + b * hsic_val * eye(size(XX));
        
        % 原始约束项
        U1 = U1 + W_sibling * W_sibling';
        U2 = U2 + W_sibling;
    end

    % 融合所有约束项
    W_parent = W{parentIndex};
    parentChildConsis = a * (W_current - W_parent);
    childParentConsis = a * (W_parent - W_current);
    
    % 最终权重更新
    W_node = (XX + lambda * D + beta*(ones(size(XX))-eye(size(XX))) + ...
             a*eye(size(XX)) + alpha*U1 + U_HSIC) \ ...
             (XY + parentChildConsis + childParentConsis + alpha*U2);
end