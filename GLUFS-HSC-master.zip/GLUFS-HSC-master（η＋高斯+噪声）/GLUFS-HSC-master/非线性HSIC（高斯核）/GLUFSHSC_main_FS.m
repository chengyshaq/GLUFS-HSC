function [feature_slct, hsicInfo] = GLUFSHSC_main_FS(X, Y, tree, lambda, alpha, beta, a, b, maxIte, flag, kernelType, sigma)
    % 新增输入参数: kernelType, sigma
    % 返回hsicInfo结构体包含HSIC值和计算时间
    
    % 初始化记录器
    hsicInfo.values = zeros(maxIte,1);
    hsicInfo.times = zeros(maxIte,1);
    % 提取非叶节点和根节点
    internalNodes = tree_InternalNodes(tree);  % 获取内部节点（非叶节点）
    indexRoot = tree_Root(tree);               % 获取根节点索引
    noLeafNode = [internalNodes; indexRoot];   % 所有非叶节点的索引
    numSelected = size(X{indexRoot},2);        % 根节点的特征数量

    % 获取每个节点的类别数，并找到最大类别数
    for i = 1:length(noLeafNode)
        ClassLabel = unique(Y{noLeafNode(i)});
        m(noLeafNode(i)) = length(ClassLabel);
    end
    maxm = max(m);  % 最大类别数
    
    % 初始化权重矩阵和标签矩阵
    for j = 1:length(noLeafNode)
        [~, d] = size(X{noLeafNode(j)});  % 特征维度
        Y{noLeafNode(j)} = conversionY01_extend(Y{noLeafNode(j)}, maxm);  % 扩展标签矩阵到最大类别数
    % 改为随机初始化（均值为1的小扰动）
    W{noLeafNode(j)} = ones(d, maxm) + 0.01*randn(d, maxm); 
    end

    % 迭代优化
    for iter = 1:maxIte
        % 计算正则化矩阵和协方差矩阵
        for j = 1:length(noLeafNode)
            D{noLeafNode(j)} = diag(0.5 ./ max(sqrt(sum(W{noLeafNode(j)} .^ 2, 2)), eps));  % 计算正则化对角矩阵
            XX{noLeafNode(j)} = X{noLeafNode(j)}' * X{noLeafNode(j)};  % 计算特征矩阵的协方差矩阵
            XY{noLeafNode(j)} = X{noLeafNode(j)}' * Y{noLeafNode(j)};  % 计算特征矩阵与标签矩阵的乘积
        end

        % 更新根节点的权重矩阵
        W{indexRoot} = UpdateWeightRoot(XX{indexRoot}, XY{indexRoot}, D{indexRoot}, W, indexRoot, lambda, beta, a);

        % 更新内部节点的权重矩阵
        for j = 1:length(internalNodes)
            nodeIndex = internalNodes(j);
            
            %% 修正函数调用语句
W{nodeIndex} = UpdateWeightInternal(XX{nodeIndex}, XY{nodeIndex}, D{nodeIndex},W, nodeIndex, tree,lambda, alpha, beta, a, b,kernelType, sigma);
        end
    
        % 计算目标函数值（可选）
        if flag == 1
            [obj(iter), hsicInfo.values(iter), hsicInfo.times(iter)] = ComputeObjective(X, Y, W, D, tree, lambda, alpha, beta, a, b, noLeafNode, kernelType, sigma);
        % 监控NaN值
        if isnan(obj(iter))
            error('NaN detected in objective at iteration %d. Check HSIC values.', iter);
        end
        end
    end
     % 特征选择
    for i = 1:length(noLeafNode)
        W1 = W{noLeafNode(i)};
        W{noLeafNode(i)} = W1(:, 1:m(noLeafNode(i)));  % 截取有效的类别列
    end
    for j = 1:length(noLeafNode)
        tempVector = sum(W{noLeafNode(j)} .^ 2, 2);  % 计算每个特征的权重
        [~, value] = sort(tempVector, 'descend');  % 按特征权重降序排序
        feature_slct{noLeafNode(j)} = value(1:numSelected);  % 选择前 numSelected 个特征
    end

    % 绘制目标函数曲线（可选）
    if flag == 1
        figure('Color', [1 1 1]);
        plot(obj, 'LineWidth', 2, 'Color', [0 0 1]);
        xlabel('Iteration number');
        ylabel('Objective function value');
        title('Objective Function Convergence');
    end