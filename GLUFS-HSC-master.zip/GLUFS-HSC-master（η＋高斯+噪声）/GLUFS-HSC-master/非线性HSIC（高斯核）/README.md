The MATLAB code of the paper 'A Global and Local Unified Feature Selection Algorithm Based on
Hierarchical Structure Constraints'

If you want to run Gaussian kernel functions, first remove the original GLUFS-HSC and the functions of HSIC and H from the path before running.

Run the file GLUFSHSC_main.m. 
