%% 修改后的 HSIC 函数（关键修复）
function [numHSIC, sigmaUsed, compTime] = HSIC(W1, W2, kernelType, sigma)
    tStart = tic;
    [m, ~] = size(W1);
    Hn = eye(m) - (1/m)*ones(m);
    
    % 输入矩阵检查
    if any(isnan(W1(:))) || any(isinf(W1(:))), error('W1 contains NaN/Inf!'); end
    if any(isnan(W2(:))) || any(isinf(W2(:))), error('W2 contains NaN/Inf!'); end

    switch lower(kernelType)
        case 'linear'
            K1 = W1 * W1';
            K2 = W2 * W2';
            sigmaUsed = NaN;
            
        case 'gaussian'
            % 自适应带宽计算（增加鲁棒性）
            if isempty(sigma) || strcmpi(sigma,'auto')
                D1 = pdist(W1, 'euclidean').^2;
                sigma1 = sqrt(0.5 * median(D1));
                D2 = pdist(W2, 'euclidean').^2;
                sigma2 = sqrt(0.5 * median(D2));
                sigmaUsed = mean([sigma1, sigma2]);
                
                % 关键修复：防止零值
                sigmaUsed = max(sigmaUsed, eps*100); % 确保最小值
            else
                sigmaUsed = sigma;
            end
            
            % 高斯核计算
            K1 = exp(-squareform(pdist(W1,'squaredeuclidean'))/(2*sigmaUsed^2 + eps));
            K2 = exp(-squareform(pdist(W2,'squaredeuclidean'))/(2*sigmaUsed^2 + eps));
            
        otherwise
            error('Unsupported kernel type: %s', kernelType);
    end
    
    numHSIC = trace(K1 * Hn * K2 * Hn);
    compTime = toc(tStart);
end