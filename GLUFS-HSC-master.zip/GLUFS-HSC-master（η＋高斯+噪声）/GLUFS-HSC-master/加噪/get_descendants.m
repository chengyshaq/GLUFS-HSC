function descendants = get_descendants(tree, node)
    % �Ľ��ĺ����ȡ�������������������
    descendants = [];
    queue = node;
    visited = false(size(tree,1),1);
    
    while ~isempty(queue)
        current = queue(1);
        queue(1) = [];
        
        if ~visited(current)
            visited(current) = true;
            children = find(tree(:,1) == current);
            descendants = [descendants; children(:)];
            queue = [queue; children(:)];
        end
    end
    descendants = unique(descendants);
end

