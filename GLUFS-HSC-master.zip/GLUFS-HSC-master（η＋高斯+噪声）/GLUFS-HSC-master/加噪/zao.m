% 加载原始数据
load('CLEFTrain.mat', 'data_array', 'tree');

% 生成不同噪声配置
noise_configs = {
    struct('name', 'mixed5+25',     'parent', 5, 'sibling', 25)...
};

for i = 1:length(noise_configs)
    cfg = noise_configs{i};
    [noisy_data, noisy_tree] = add_hierarchy_noise(data_array, tree, cfg.parent, cfg.sibling);
    save(sprintf('CLEFTrain_%s.mat', cfg.name), 'noisy_data', 'noisy_tree');
end
