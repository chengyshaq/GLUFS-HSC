The MATLAB code of the paper 'A Global and Local Unified Feature Selection Algorithm Based on
Hierarchical Structure Constraints'

If you want to manually add noise to the data set, run the main function zao.m, store the noised data set.

Run the file GLUFSHSC_main.m. 
