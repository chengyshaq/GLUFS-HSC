%% 辅助函数：获取父节点索引
function parentIndex = tree_Parent(tree, nodeIndex)
    parentIndex = tree(nodeIndex, 1);
end